import streamlit as st
from pathlib import Path
import re, json

st.set_page_config(page_title="CareerPilot AI", page_icon="🚀", layout="wide")

st.title("🚀 CareerPilot AI")
st.caption("Private, local-first career intelligence for Snapdragon-powered HP PCs")

with st.sidebar:
    st.header("Runtime")
    st.info("Prototype mode")
    st.write("Target: Snapdragon X Series / Windows 11")
    st.write("AI Hub targets:")
    st.write("• Llama 3.2 3B Instruct SSD")
    st.write("• Whisper Small Quantized")
    st.divider()
    st.write("No resume or job description is uploaded to a cloud service by this prototype UI.")

def extract_skills(text):
    catalog = [
        "Python","SQL","Power BI","Excel","Java","C++","C","PHP","Django",
        "Machine Learning","Deep Learning","Data Science","Data Analytics",
        "Business Analytics","Pandas","NumPy","Scikit-learn","TensorFlow",
        "PyTorch","Git","GitHub","AWS","Azure","Docker","PowerPoint",
        "Communication","Problem Solving","Statistics"
    ]
    low = text.lower()
    return sorted([s for s in catalog if s.lower() in low])

def read_text_file(uploaded):
    raw = uploaded.read()
    try:
        return raw.decode("utf-8", errors="ignore")
    except Exception:
        return str(raw)

def local_llm_prompt(task, context):
    # Replace this adapter with your Qualcomm AI Runtime / local model call.
    # Keep the interface identical so the UI does not change.
    return f"[LOCAL AI PLACEHOLDER]\nTask: {task}\nContext: {context[:2500]}"

tabs = st.tabs(["Resume Analyzer", "Job Match", "Interview Practice", "Architecture"])

with tabs[0]:
    st.subheader("1. Resume Analyzer")
    resume = st.file_uploader("Upload resume text export (.txt) for prototype", type=["txt"])
    if resume:
        text = read_text_file(resume)
        skills = extract_skills(text)
        st.metric("Skills detected", len(skills))
        st.write(", ".join(skills) if skills else "No catalogued skills detected.")
        st.markdown("### Local AI summary")
        st.code(local_llm_prompt("Summarize the candidate's strengths and missing skills.", text), language="text")

with tabs[1]:
    st.subheader("2. Job Match & Skill Gap")
    c1, c2 = st.columns(2)
    with c1:
        resume_text = st.text_area("Resume text", height=260)
    with c2:
        jd_text = st.text_area("Job description", height=260)
    if st.button("Analyze Match"):
        rs = set(extract_skills(resume_text))
        js = set(extract_skills(jd_text))
        matched = sorted(rs & js)
        missing = sorted(js - rs)
        score = round((len(matched) / max(1, len(js))) * 100)
        st.metric("Catalog skill match", f"{score}%")
        st.write("Matched skills:", ", ".join(matched) or "None")
        st.write("Skill gaps:", ", ".join(missing) or "None")
        st.markdown("### Suggested next steps")
        st.code(local_llm_prompt("Create a 30-day learning plan for the missing skills.", ", ".join(missing)))

with tabs[2]:
    st.subheader("3. Voice Interview Practice")
    st.write("Use the Whisper Small Quantized model through the local Qualcomm runtime to transcribe answers.")
    question = st.selectbox("Question", [
        "Tell me about yourself.",
        "Explain a data project you built.",
        "How would you clean a messy dataset?",
        "Why should we hire you for a data analyst role?"
    ])
    st.write("Question:", question)
    st.text_area("Transcript / local speech-to-text output", height=180)
    st.button("Evaluate Answer")
    st.caption("The production adapter will score structure, relevance and clarity locally with the LLM.")

with tabs[3]:
    st.subheader("4. Snapdragon deployment architecture")
    st.markdown("""
**User → CareerPilot UI → Local AI Orchestrator**

- Resume/JD parser → local text extraction
- Llama 3.2 3B Instruct SSD → reasoning, summaries, skill-gap explanations
- Whisper Small Quantized → offline speech-to-text
- Qualcomm AI Runtime / ONNX Runtime execution path → Snapdragon CPU/NPU
- Local storage only → no cloud upload by default

The final Snapdragon build should benchmark latency, memory, NPU utilization and battery impact on an HP Snapdragon PC.
""")
