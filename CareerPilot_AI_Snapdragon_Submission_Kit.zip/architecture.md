# CareerPilot AI — Technical Architecture

## Production path
1. User opens the local Windows app.
2. Resume/JD text stays on device.
3. Llama 3.2 3B Instruct SSD handles summarization, reasoning and learning-plan generation.
4. Whisper Small Quantized handles speech-to-text for interview practice.
5. Qualcomm AI Runtime / ONNX Runtime routes supported operations to Snapdragon compute units.
6. Results are rendered locally; no cloud upload is required.

## Benchmark plan
Measure:
- Time to first token
- Tokens/sec
- Speech transcription latency
- Peak RAM
- NPU utilization
- CPU utilization
- Battery drain for a fixed 15-minute session

## Security
- Local-first storage
- No telemetry by default
- User-controlled document deletion
- No API key required for the local inference path
