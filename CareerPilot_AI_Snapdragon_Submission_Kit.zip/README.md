# CareerPilot AI: Private On-Device Career Copilot

CareerPilot AI is a privacy-first career assistant intended for Snapdragon-powered HP PCs.

## Core use case
- Resume and job-description analysis
- Skill extraction and gap detection
- Personalized learning roadmap
- Voice interview practice
- Local-first processing for sensitive career documents

## Snapdragon / AI Hub target
The submission is designed around Qualcomm AI Hub models that support Snapdragon X platforms:
- Llama 3.2 3B Instruct / SSD variant for local text generation
- Whisper Small Quantized for speech-to-text
- Qualcomm AI Runtime / ONNX Runtime deployment path

## Important submission note
The included UI is a prototype scaffold. Before final submission, run the model adapters on a real Snapdragon-powered HP PC and record measured latency, memory and NPU utilization. Do not claim NPU/offline performance until it has been verified.

## Run
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## GitHub
Create a public repository and replace the placeholder in the submission form with the real URL.

## Suggested repository structure
```
careerpilot-ai/
  app.py
  requirements.txt
  README.md
  architecture.md
  .gitignore
```
